# cow-name-label-a02 > 2023-12-29 10:01pm
https://universe.roboflow.com/cowlabela02/cow-name-label-a02

Provided by a Roboflow user
License: CC BY 4.0

