# cow-label-a04-name > 2025-07-05 11:18am
https://universe.roboflow.com/cowlabel-vknw5/cow-label-a04-name

Provided by a Roboflow user
License: CC BY 4.0

